// content.js
(async function() {
    // Maak een container div
    const container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.top = '10px';
    container.style.right = '10px';
    container.style.zIndex = '9999';
    container.style.backgroundColor = 'rgb(171, 199, 223)';
    container.style.padding = '20px';
    container.style.borderRadius = '10px';
    container.style.boxShadow = '0 0 10px rgba(0,0,0,0.5)';
    container.style.maxWidth = '300px';
    container.style.fontFamily = '"Capriola", sans-serif';
    
    // Voeg HTML inhoud toe (je kunt dit uit popup.html halen)
    container.innerHTML = `
        <h1>Let op!</h1>
        <img src="${chrome.runtime.getURL('LogoF.png')}" alt="logo" style="width:50px; display:block; margin-bottom:10px;">
        <p>Deze pagina verspreid een gevaarlijk wereldbeeld, neem niet alles aan voor waarheid en bij twijfel bezoek onze website.</p>
        <a href="https://naduavg.github.io/Feesboek/" target="_blank" style="color:white; background-color: rgb(15, 44, 103); padding: 5px 10px; border-radius: 5px; text-decoration:none; display:inline-block;">Link</a>
    `;

    // Voeg toe aan body
    document.body.appendChild(container);
})();
